Unity3D Version - 2019.2.17
Vuforia Version - 8.5.9
Youtube link for working of the app - https://youtu.be/-zbOmAp3L1U